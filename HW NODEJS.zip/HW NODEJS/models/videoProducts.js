const Sequelize = require('sequelize');
const MySql = require('../libs/MySql')

class Products extends Sequelize.Model {
  static async connect () {
    let connected = false;
    let sequelize = await MySql.Open();
    Products.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      videoname: Sequelize.STRING,
      videotype: Sequelize.STRING,
      custom: Sequelize.STRING
    }, {
      sequelize,
      modelName: 'video'
    });
    connected = true;
    return connected;
  }

  static async close() {
    let status = await MySql.Close();
    return status
  }
}

module.exports = Products