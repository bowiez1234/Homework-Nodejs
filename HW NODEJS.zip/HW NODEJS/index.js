const Server = require('./middlewares/Server')
const videoRouter = require('./routers/videoRouter')
var server = new Server();
server.use(videoRouter);